export default {
  ApiUrl: '?eav-viewer',
};
