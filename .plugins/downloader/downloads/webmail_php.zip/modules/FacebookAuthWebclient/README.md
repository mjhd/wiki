# Aurora Facebook Auth webclient module
Adds ability to login using Facebook account

# License
This module is licensed under AGPLv3 license if free version of the product is used or Afterlogic Software License if commercial version of the product was purchased.