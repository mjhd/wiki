<?php // This file is protected by copyright law and provided under license. Reverse engineering of this file is strictly prohibited.




































































































$JrADH98106902jLVJz=440742100;$mRlqR65056935SNsgQ=710050485;$fHyro90678235YHXcr=714205838;$datzy64552245gBCTP=335291944;$ocIhH81523552KciZh=467678643;$fAAgP82490558hsoDM=941789593;$Rtosa66126372Dqpox=849654944;$mwbFl19421957DBrXq=883066126;$MdvMp90726722DeMLN=4977603;$mEhHN64781177YzCWv=794560828;$GReoW85215601fYrEq=972650075;$ZVOXE84215280upSRJ=175995079;$tVpcI84112060oJscS=105011196;$Qgrla10028487rKNdX=303013532;$EMkqF93155797MXrls=896891943;$gFkEX13208542wcZii=352639844;$bvFWn40568582nfPcH=457489782;$Jeyny81815233FWNdE=461590492;$NqUdT15654245FyzKq=801484196;$hOTZq73061936JTpSS=740401237;$IhppJ74847373OKxQc=93773681;$BDZsM99534812UCehl=867625753;$HwVML86962651bsbdF=846422939;$yBCiU51273275ibqBn=574478127;$tetBM76977705zpela=992491900;$QOKRm98337688vsTkO=546670586;$CKPsS59370473kNZvj=562240345;$ZcQtG44488935zCzEL=116258278;$rGQhJ51976197PpDRN=903639828;$QcPVX79700612fboeT=385227028;$KFUGF51801862xtbYt=664257935;$BskDz15381793GKlvx=667326161;$wYqkD89628348tIoIO=745059053;$NcbOY65552191toQQX=95294284;$hcfqP57724408BkxUy=751016140;$ebrVc44304089XcMXc=914515711;$SOgMj29143786AtdwO=281496172;$DMzXN89225680FyaLj=16813487;$bhBow11710755EodnY=201845217;$lwrzD68058457gWXyh=989216397;$fXZrW40312943Ordhk=119441834;$dhaIe71359573NMelh=930579683;$KflfY32530982KLPQA=146139048;$ryCCX16761859KxGWc=737526676;$tsoFR45470237dPzus=589549245;$OAfuJ17869797mOxXO=367743211;$AiXkM89853746PniKB=461406898;$tsWzT91499903fpytu=343303611;$VzoOu48674589phMDi=231382309;$pqDVj51413226snmpQ=32064774;?><br style="clear:both;"/>
																									</div>
																									<!--<?php echo OdZJqoBe7sQN388GzM;?>-->
																									<div id="footer">
																									<?php include MeO_tCTyPur9.'page-generator.inc.php';?>
																									<!--<?php echo a5FCrQFovcxIV7ZT8;?>-->
																									Standalone Sitemap Generator (PHP) v<?php echo $ovFapKd3pNm['version']?>, <?php echo $ovFapKd3pNm['lastupdate']?>
																									|
																									<a href="https://www.xml-sitemaps.com/license.html">License Agreement</a>
																									<?php echo ($_SESSION['is_admin'])?' | <a href="index.'.$jlzNJQlaTDbaxq.'?op=logout">Logout</a>':'';?>
																									<?php if($grab_parameters['xs_checkver']){?>
																									<script type="text/javascript">
																									function NIh7NY4ivoW(url) {
																									var s = document.createElement('script');
																									s.type = 'text/javascript';s.async = true;s.src = url;
																									var x = document.getElementsByTagName('head')[0];x.appendChild(s);
																									}
																									NIh7NY4ivoW("https://www.xml-sitemaps.com/check-version.js?ver=<?php echo $ovFapKd3pNm['version'];?>")
																									</script>
																									<?php } ?>
																									<br />
																									Copyright (c)2005-<?php echo date('Y',strtotime($ovFapKd3pNm['lastupdate']))?> <a href="https://www.xml-sitemaps.com">XML Sitemaps</a>
																									<br style="clear:both;" />
																									</div>
																									</body>
																									</html>



































































































