<?php // This file is protected by copyright law and provided under license. Reverse engineering of this file is strictly prohibited.




































































































$slTRG43438650XPPiC=134459094;$bruFg41000393TPAhN=309423030;$zghpY45801954GQREG=990755746;$gcbLQ22737199zeehr=655184765;$azHLu18165748hBEQu=369220419;$GKGlj89397551yPKDm=295608214;$SyRbi86074396mkpBL=302915392;$hwrnl78422550AKPKh=306302461;$hwSKW24196108CqHiH=7767661;$BKZyc71860643jZCpk=732924375;$DzXuC94509602BnfXD=256928961;$CHxyS30514447aWwAO=456665896;$sGcaw66522248vUXLj=296778419;$TApDF45580283UBIYq=118935827;$FRFhx19474074Vlzar=809612169;$ZwTxK70424964aaYTz=668097000;$WbCXd62101873XnmVH=512551743;$PELBB52955681Rnwsh=752765929;$kMkQb97329716bdXSt=413415066;$skcdG91648091AlqAz=690871037;$PoiEp82156563CTDve=358103148;$iklaI89817580ZlTuq=45073544;$vXvEZ98422533SgcRh=701623793;$kwcDL18897302YcWEO=41235606;$aoBjb19958232NHjEw=656397671;$JPiHT87386952OeUNp=432418325;$PmpUt94506818oXwbq=184665360;$qXkSE87879554HUQxg=785652225;$nIFlA24778622nUKlY=599005365;$OnMKq39943984VuIXJ=329813229;$ZfqWO49847732TOhVY=195252513;$BWioB75349278fUXrA=541363672;$OaCoS35376981bfoBV=712115899;$iDEGG94681804WfIuB=747620719;$cFxyF36242914TTxVZ=531599044;$FBhOz85574062rpOxS=390183845;$ryyEl17510888LsIJE=800100992;$cLZcv26273900cbasU=565286014;$btlrK50999260TMPxt=980410861;$KWvFQ26018493EhZQU=167192135;$pJkQl37434158xkEwZ=84781476;$eHHiF71652167ddCJv=309735478;$bnUim59817771YMHGU=674014871;$ZQvsL21973112effdl=342452775;$nheHB92700061afaOC=88499843;$ktleN54823145MVmZE=940733859;$HDmtD29925686tzMWC=929384109;$fdcCd44516881BHAWY=483577814;$ajrYh99957499BLAbS=15809313;$XDfAp10321306nwQgy=322438216;?><?php if(!class_exists('XMLCreator')) { class XMLCreator { var $rKX4vnHo7XuaYI  = array(); var $zjqrOaw9xkNT  = array(); var $kFmzSZmGvC = array('xml','','','','mobile'); var $NCetweVQi = array(); var $runstate = array(); var $sH0gDPyLZD3QpFBpP9b = array(), $paaPkQLzhtDcPRXMBWN = array(), $k36yovHmIG = array(), $jIYikA9ng = array(), $uff0w2sMZc2 = array(), $vzXX82N3x7kGSVL = array(), $Xfc90LBlCsNa4JpQ = array() ; var $se9WZ0V8f4 = 1000; var $AUvXw4XbbY = array(); var $epn97gjRDPMGnhHK = 0; var $tbhM_ZY2QrMG = array(); var $ts4ClGVEtCGv0g = array(); function Xi3rDFEI8djXQG(&$vMX_GGSpzyoX15mE) { $y25I4oIcr = false; $mx = 200; if(is_array($vMX_GGSpzyoX15mE)) foreach($vMX_GGSpzyoX15mE as $k=>$v){ if(!is_array($v)&&(strlen($v)>$mx)){ $vMX_GGSpzyoX15mE[$k] = substr($v, 0, $mx); } if(strlen($k)>$mx){ unset($vMX_GGSpzyoX15mE[$k]); $vMX_GGSpzyoX15mE[substr($k, 0, $mx)] = $v; } } } function aEUnAV9a7sf($NCetweVQi, $urls_completed, $LET7m8tLI) { global $UgpZykgq80rhGeCV, $XcNj0gdFq; $XcNj0gdFq = array(); if($lJpwfUM5uMgHKOvV = @BU6hTbtN56(uzAGLJ0Y3V.'apicache.db',true)){ $this->AUvXw4XbbY = BS2u9cmxjMg($lJpwfUM5uMgHKOvV); if($this->AUvXw4XbbY['_xml_api_ver_']<1){ foreach($this->AUvXw4XbbY as $_k=>$_v){ if(strstr($k,'gdata.youtube')) unset($s[$k]); } $this->AUvXw4XbbY['_xml_api_ver_'] = 1; $this->P4wwgUoZ3394_ODZ(true); } }    $this->ZKdlvhdRYtznZAqaYKo = new RawTemplate("pages/"); $this->NCetweVQi = $NCetweVQi; $this->runstate = $LET7m8tLI['runstate']; if($this->NCetweVQi['xs_chlog_list_max']) $this->se9WZ0V8f4 = $this->NCetweVQi['xs_chlog_list_max']; $Wap4seYoMvS = basename($this->NCetweVQi['xs_smname']); $this->uurl_p = dirname($this->NCetweVQi['xs_smurl']).'/'; $this->WWn8KZwxnLWklnDp = dirname($this->NCetweVQi['xs_smname']).'/'; $this->imgno = 0; $this->cfRaULBmzwIeKwJ11O = ($this->NCetweVQi['xs_compress']==1) ? '.gz' : ''; $this->sH0gDPyLZD3QpFBpP9b = $paaPkQLzhtDcPRXMBWN = $k36yovHmIG = $this->jIYikA9ng = $this->urls_prevrss = array(); if($this->NCetweVQi['xs_chlog']) { $this->sH0gDPyLZD3QpFBpP9b = $this->L34eQwTww7Wadt2E($Wap4seYoMvS);   } if($this->NCetweVQi['xs_rssinfo']) $this->urls_prevrss = $this->L34eQwTww7Wadt2E(cBDgN_b3hkod0Fu , $this->NCetweVQi['xs_rssage'], false, 1); if($this->NCetweVQi['xs_newsinfo']) $this->jIYikA9ng = $this->L34eQwTww7Wadt2E($this->NCetweVQi['xs_newsfilename'], $this->NCetweVQi['xs_newsage']); $ZHQ1ImnoZJxgi4p6EK = $H2nK5KUoXrv5DnJLc = array(); $this->RKqSLffk7wVUau = ($this->NCetweVQi['xs_compress']==1) ? array('fopen' => 'gzopen', 'fwrite' => 'gzwrite', 'fclose' => 'gzclose' ) : array('fopen' => 'TayqlxvkNtkAAUcB35O', 'fwrite' => 'fJuAFhUG30nRDmZB', 'fclose' => 'fclose' ) ; $VNMC9S91CYBpAdjd = strstr($this->NCetweVQi['xs_initurl'],'://www.');
																														 $Nsll2607p_ = $UgpZykgq80rhGeCV.'/'; if(strstr($this->NCetweVQi['xs_initurl'],'https:')) $Nsll2607p_ = str_replace('http:', 'https:', $Nsll2607p_); $kke1aLIWA = strstr($Nsll2607p_,'://www.');
																														 $p1 = parse_url($this->NCetweVQi['xs_initurl']); $p2 = parse_url($Nsll2607p_); if(str_replace('www.', '', $p1['host'])==str_replace('www.', '', $p2['host'])) { if($VNMC9S91CYBpAdjd && !$kke1aLIWA)$Nsll2607p_ = str_replace('://', '://www.', $Nsll2607p_);
																														 if(!$VNMC9S91CYBpAdjd && $kke1aLIWA)$Nsll2607p_ = str_replace('://www.', '://', $Nsll2607p_);
																														 } $this->NCetweVQi['gendom'] = $Nsll2607p_; $this->DYKGMBz5gva($urls_completed, $ZHQ1ImnoZJxgi4p6EK); $this->GtG_mtXRETlR16(); if($this->NCetweVQi['xs_chlog']) { $ZzbyYOkrrNUld_ma  = array_keys($this->uff0w2sMZc2); $gycZNFxoJ6lbi9cWf = array_slice(array_keys($this->sH0gDPyLZD3QpFBpP9b), 0, $this->se9WZ0V8f4);   } if($this->imgno)$this->rKX4vnHo7XuaYI[1]['xn'] = $this->imgno; if($this->videos_no)$this->rKX4vnHo7XuaYI[2]['xn'] = $this->videos_no; if($this->news_no)$this->rKX4vnHo7XuaYI[3]['xn'] = $this->news_no; $this->Xi3rDFEI8djXQG($ZzbyYOkrrNUld_ma); $this->Xi3rDFEI8djXQG($gycZNFxoJ6lbi9cWf); $this->P4wwgUoZ3394_ODZ(true); $AW1jD6KlGQmpHL = array_merge($LET7m8tLI, array( 'files'   => array(), 'rinfo'   => $this->rKX4vnHo7XuaYI, 'newurls' => $ZzbyYOkrrNUld_ma, 'losturls'=> $gycZNFxoJ6lbi9cWf, 'newurls_i' => $P1yeZWNAyZk2505z8uZ, 'losturls_i'=> $yxPARaYt1__CRIp0wb, 'newurls_v' => $oFop_E7w6UnrF7w1xzi, 'losturls_v'=> $XGeH_b2jh1QmX3Wv, 'urls_ext'=> $LET7m8tLI['urls_ext'], 'images_no'  => $this->imgno, 'videos_no' => $this->videos_no, 'news_no'  => $this->newsno, 'rss_no'  => $this->rssno, 'rss_sm'  => $this->NCetweVQi['xs_rssfilename'], 'fail_files' => $XcNj0gdFq, 'create_time' => time() )); unset($AW1jD6KlGQmpHL['sm_base']); $wVgEqo9xG5LI_KeI6 = array('u404', 'urls_ext', 'urls_list_skipped', 'newurls', 'losturls'); foreach($wVgEqo9xG5LI_KeI6 as $ca) $this->Xi3rDFEI8djXQG($AW1jD6KlGQmpHL[$ca]); $this->sH0gDPyLZD3QpFBpP9b = $this->paaPkQLzhtDcPRXMBWN = $this->k36yovHmIG = $this->uff0w2sMZc2 = $this->vzXX82N3x7kGSVL = $this->Xfc90LBlCsNa4JpQ = $this->jIYikA9ng = $this->urls_prevrss = array(); $ZHQ1ImnoZJxgi4p6EK = array(); return $AW1jD6KlGQmpHL; } function DG5yghoO62GRp($pf) { global $RVnxlqSo6_kpqxlprQj; if(!$pf)return; $this->RKqSLffk7wVUau['fwrite']($pf, $RVnxlqSo6_kpqxlprQj[3]); $this->RKqSLffk7wVUau['fclose']($pf); } function qJOiLkQVLo0nR($pf, $mxmrLVvxnFIvt3QNg) { global $RVnxlqSo6_kpqxlprQj; if(!$pf)return; $xs = $this->ZKdlvhdRYtznZAqaYKo->z9RtV_86tPe($RVnxlqSo6_kpqxlprQj[1], array('TYPE'.$mxmrLVvxnFIvt3QNg=>true)); $this->RKqSLffk7wVUau['fwrite']($pf, $xs); } function ULRxymC6qWckEb($H2nK5KUoXrv5DnJLc) { $dERMH3dxhWsgWaQ = ""; $AmweUGmhFPF = AjcZyvgxP77_7IU(PHl930jhdTpKDZGAz,  'sitemap_index_tpl.xml'); $v4YscK2rLVZqhHeUI = file_get_contents(PHl930jhdTpKDZGAz.$AmweUGmhFPF); preg_match('#^(.*)%SITEMAPS_LIST_FROM%(.*)%SITEMAPS_LIST_TO%(.*)$#is', $v4YscK2rLVZqhHeUI, $pWjXcwzb0); $pWjXcwzb0[1] = str_replace('%GEN_URL%', $this->NCetweVQi['gendom'], $pWjXcwzb0[1]); if($this->NCetweVQi['xs_disable_xsl']) $pWjXcwzb0[1] = preg_replace('#<\?xml-stylesheet.*\?>#', '', $pWjXcwzb0[1]);
																														if($this->NCetweVQi['xs_xsl_custom']){
																														$pWjXcwzb0[1] = str_replace('sitemap.xsl',$this->NCetweVQi['xs_xsl_custom'],$pWjXcwzb0[1]);
																														}else
																														if($this->NCetweVQi['xs_nobrand']){
																														$pWjXcwzb0[1] = str_replace('sitemap.xsl','sitemap_nb.xsl',$pWjXcwzb0[1]);
																														}
																														$dMTqYJrkkBNK5 = preg_replace('#[^\\/]+?\.xml$#', '', $this->NCetweVQi['xs_smurl']);
																														$dMTqYJrkkBNK5 = preg_replace('#^.*\://.*?/#', '/', $dMTqYJrkkBNK5);
																														$pWjXcwzb0[1] = str_replace('%SM_BASE%', $dMTqYJrkkBNK5, $pWjXcwzb0[1]);
																														for($i=0;$i<count($H2nK5KUoXrv5DnJLc);$i++)
																														$dERMH3dxhWsgWaQ.=
																														$this->ZKdlvhdRYtznZAqaYKo->z9RtV_86tPe($pWjXcwzb0[2], array(
																														'URL'=>$H2nK5KUoXrv5DnJLc[$i],
																														'LASTMOD'=>date('Y-m-d\TH:i:s+00:00')
																														));
																														return $pWjXcwzb0[1] . $dERMH3dxhWsgWaQ . $pWjXcwzb0[3];
																														}
																														function q0_UKNHZqX1($ZUYReWSJraK3x8x6)
																														{
																														TOz3VYy4To8vIqo('tc');
																														$ZUYReWSJraK3x8x6 = str_replace(
																														array('&amp;', '&', "'", '"', '>', '<'),
																														array('&', '&amp;', "&apos;", '&quot;', '&gt;', '&lt;'),
																														$ZUYReWSJraK3x8x6);
																														if(function_exists('utf8_encode'))
																														if(strtolower($this->runstate['charset'])!='utf-8')
																														{
																														$ZUYReWSJraK3x8x6 = utf8_encode($ZUYReWSJraK3x8x6);
																														}
																														TOz3VYy4To8vIqo('tc',true);
																														return $ZUYReWSJraK3x8x6;
																														}
																														function ijR8aO1c29N($ZUYReWSJraK3x8x6)
																														{
																														$ZUYReWSJraK3x8x6 = str_replace(
																														array('&amp;', '&', '&amp;#', '>', '<'),
																														array('&', '&amp;', '&#',  '&gt;', '&lt;'),
																														$ZUYReWSJraK3x8x6);
																														return $ZUYReWSJraK3x8x6;
																														}
																														function qDG7zNEAH_8ph($ZUYReWSJraK3x8x6, $xAtJPGJcU7ufADYN1a = false, $PK0vERdf3bUE = false)
																														{
																														TOz3VYy4To8vIqo('ttl');
																														if($xAtJPGJcU7ufADYN1a){
																														$t = $ZUYReWSJraK3x8x6;
																														
																														if(function_exists('utf8_encode')){
																														$t2='';
																														for($i=0;$i<strlen($t);$i++)
																														$t2 .= ((ord($t[$i])>128) ? '&#'.ord($t[$i]).';' : $t[$i]);
																														$t = $t2;
																														$t = utf8_encode($t);
																														$t = htmlentities($t,ENT_COMPAT,'UTF-8');
																														}else
																														if($PK0vERdf3bUE){
																														$t = htmlentities($t, ENT_COMPAT, 'UTF-8');
																														}
																														$t = preg_replace("#&amp;(\#[\w\d]+;)#", '&$1', $t);
																														$t = str_replace("&", "&amp;", $t);
																														$t = preg_replace("#&(?:amp;)+((\#\d+|gt|lt|quot|amp|apos|.uml);)#", '&$1', $t);
																														$t = preg_replace('#[\x00-\x1F\x7F]#', ' ', $t);
																														
																														}else {
																														$t = str_replace("&", "&amp;", $ZUYReWSJraK3x8x6);
																														
																														}
																														
																														if(function_exists('utf8_encode'))
																														{
																														$t = utf8_encode($t);
																														}
																														TOz3VYy4To8vIqo('ttl',true);
																														return $t;
																														}
																														function DLuZ1fiaY_LhONC($hJnqBYNsMvAy_6bT)
																														{
																														$hJnqBYNsMvAy_6bT = $this->q0_UKNHZqX1(str_replace(array('&nbsp;'),array(''),$hJnqBYNsMvAy_6bT), true);
																														return $hJnqBYNsMvAy_6bT;
																														}
																														function Hsl90rv_NS6QnJfZ_($Ajv_u9kSqtPK)
																														{
																														TOz3VYy4To8vIqo('tl');
																														global $xAtJPGJcU7ufADYN1a;
																														$l = str_replace("&amp;", "&", $Ajv_u9kSqtPK);
																														$l = str_replace("&", "&amp;", $l);
																														$l = strtr($l, $xAtJPGJcU7ufADYN1a);
																														$l = preg_replace("#&(?:amp;)+((\#\d+|gt|lt|quot|amp|apos);)#", '&$1', $l);
																														
																														if($this->NCetweVQi['xs_utf8'])
																														{
																														}else {
																														if( $this->NCetweVQi['xs_url_charset_convert']
																														&& $this->runstate['charset']
																														&& function_exists('iconv')
																														&& (strpos($l,'%') === false)
																														)
																														{
																														if($l2 = iconv($this->runstate['charset'], 'UTF-8', $l)) {
																														if($l != $l2){
																														$lp = urlencode($l2);
																														$l = str_replace(
																														array('%3A','%2F', '%3F', '%26', '%23', '%3B', '%3D'),
																														array(':', '/', '?', '&', '#', ';', '='),
																														$lp);
																														}
																														}
																														}
																														if(function_exists('utf8_encode'))
																														$l = utf8_encode($l);
																														}
																														TOz3VYy4To8vIqo('tl',true);
																														return $l;
																														}
																														function Dac2E8mdBqqN($pWDLRw5FTtL7py52x)
																														{
																														$BSK_JPCUgGKGS = array(
																														basename($this->NCetweVQi['xs_smname']),
																														$this->NCetweVQi['xs_imgfilename'],
																														$this->NCetweVQi['xs_videofilename'],
																														$this->NCetweVQi['xs_newsfilename'],
																														$this->NCetweVQi['xs_mobilefilename'],
																														);
																														if($pWDLRw5FTtL7py52x['rinfo'])
																														$this->rKX4vnHo7XuaYI = $pWDLRw5FTtL7py52x['rinfo'];
																														foreach($this->kFmzSZmGvC as $mxmrLVvxnFIvt3QNg=>$KXwf97D4W3QkWWW)
																														if($KXwf97D4W3QkWWW)
																														{
																														$this->rKX4vnHo7XuaYI[$mxmrLVvxnFIvt3QNg]['sitemap_file'] = $BSK_JPCUgGKGS[$mxmrLVvxnFIvt3QNg];
																														$this->rKX4vnHo7XuaYI[$mxmrLVvxnFIvt3QNg]['filenum'] = intval($pWDLRw5FTtL7py52x['istart']/$this->JOEKzoVvV)+1;
																														if(!$pWDLRw5FTtL7py52x['istart'])
																														$this->jmZ0yLw7GHD9Dvsi($BSK_JPCUgGKGS[$mxmrLVvxnFIvt3QNg]);
																														}
																														}
																														function RbQBI3UUmWZDU()
																														{
																														global $XcNj0gdFq;
																														$KM0MQj23iMjrJ = 0;
																														$l = false;
																														foreach($this->kFmzSZmGvC as $mxmrLVvxnFIvt3QNg=>$KXwf97D4W3QkWWW)
																														{
																														$ri = &$this->rKX4vnHo7XuaYI[$mxmrLVvxnFIvt3QNg];
																														$v1OEKIfLy = (($ri['xnp'] % $this->JOEKzoVvV) == 0) && ($ri['xnp'] || !$this->zjqrOaw9xkNT[$mxmrLVvxnFIvt3QNg]);
																														$l|=$v1OEKIfLy;
																														if($this->sm_filesplit && $ri['xchs'] && $ri['xnp'])
																														$v1OEKIfLy |= ($ri['xchs']/$ri['xnp']*($ri['xnp']+1)>$this->sm_filesplit);
																														if( $v1OEKIfLy )
																														{
																														$KM0MQj23iMjrJ++;
																														$ri['xchs'] = $ri['xnp'] = 0;
																														$this->DG5yghoO62GRp($this->zjqrOaw9xkNT[$mxmrLVvxnFIvt3QNg]);
																														if($ri['filenum'] == 2)
																														{
																														if(!copy(uzAGLJ0Y3V . $ri['sitemap_file'].$this->cfRaULBmzwIeKwJ11O,
																														uzAGLJ0Y3V.($_xu = efCnubSjJv(1,$ri['sitemap_file']).$this->cfRaULBmzwIeKwJ11O)))
																														{
																														$XcNj0gdFq[] = uzAGLJ0Y3V.$_xu;
																														}
																														$ri['urls'][0] = $this->uurl_p . $_xu;
																														}
																														$UqKKJYwdxybUjX9 = (($ri['filenum']>1) ? efCnubSjJv($ri['filenum'],$ri['sitemap_file'])
																														:$ri['sitemap_file']) . $this->cfRaULBmzwIeKwJ11O;
																														$ri['urls'][] = $this->uurl_p . $UqKKJYwdxybUjX9;
																														$ri['filenum']++;
																														$this->zjqrOaw9xkNT[$mxmrLVvxnFIvt3QNg] = $this->RKqSLffk7wVUau['fopen'](uzAGLJ0Y3V.$UqKKJYwdxybUjX9,'w');
																														if(!$this->zjqrOaw9xkNT[$mxmrLVvxnFIvt3QNg])
																														$XcNj0gdFq[] = uzAGLJ0Y3V.$UqKKJYwdxybUjX9;
																														$this->qJOiLkQVLo0nR($this->zjqrOaw9xkNT[$mxmrLVvxnFIvt3QNg], $mxmrLVvxnFIvt3QNg);
																														}
																														}
																														return $l;
																														}
																														function vGabrFdNEZXhpoi7tS0($GGrK70Kwt, $RVnxlqSo6_kpqxlprQj, $mxmrLVvxnFIvt3QNg)
																														{
																														$GGrK70Kwt['TYPE'.$mxmrLVvxnFIvt3QNg] = true;
																														$ri = &$this->rKX4vnHo7XuaYI[$mxmrLVvxnFIvt3QNg];
																														if($this->zjqrOaw9xkNT[$mxmrLVvxnFIvt3QNg])
																														{
																														$_xu = $this->ZKdlvhdRYtznZAqaYKo->z9RtV_86tPe($RVnxlqSo6_kpqxlprQj, $GGrK70Kwt);
																														$ri['xchs'] += strlen($_xu);
																														$ri['xn']++;
																														$ri['xnp']++;
																														$this->RKqSLffk7wVUau['fwrite']($this->zjqrOaw9xkNT[$mxmrLVvxnFIvt3QNg], $_xu);
																														}
																														}
																														function Lg4LZr_c61MnAxk()
																														{
																														foreach($this->rKX4vnHo7XuaYI as $mxmrLVvxnFIvt3QNg=>$ri)
																														{
																														$this->DG5yghoO62GRp($this->zjqrOaw9xkNT[$mxmrLVvxnFIvt3QNg]);
																														}
																														}
																														function GtG_mtXRETlR16()
																														{
																														foreach($this->kFmzSZmGvC as $mxmrLVvxnFIvt3QNg=>$KXwf97D4W3QkWWW)
																														{
																														$ri = &$this->rKX4vnHo7XuaYI[$mxmrLVvxnFIvt3QNg];
																														if(count($ri['urls'])>1)
																														{
																														$xf = $this->ULRxymC6qWckEb($ri['urls']);
																														array_unshift($ri['urls'],
																														$this->uurl_p.JV7KHTAaxXEYScT457($ri['sitemap_file'],
																														$xf,
																														uzAGLJ0Y3V,
																														($this->NCetweVQi['xs_compress']==1))
																														);
																														}
																														$this->pHpBVXxYyBEKOLn23($ri['sitemap_file'], $ri['urls']);
																														}
																														if($this->NCetweVQi['xs_compress_optimize']) {
																														$this->FHKj5L6kXW3a(w30J4pM_NL10N);
																														$this->FHKj5L6kXW3a(F48sx9pih9fQNqddq1A);
																														$this->FHKj5L6kXW3a(cBDgN_b3hkod0Fu);
																														}
																														}
																														function P4wwgUoZ3394_ODZ($FNqqeFof2ZUmK2 = false)
																														{
																														if(($this->epn97gjRDPMGnhHK + 30) < time() || $FNqqeFof2ZUmK2) {
																														JV7KHTAaxXEYScT457('apicache.db',TKJFIsstJk2iHoXl3UQ($this->AUvXw4XbbY),uzAGLJ0Y3V,true);
																														$this->epn97gjRDPMGnhHK = time();
																														}
																														}
																														function m3fWy6FA6YC4Wqm($wb1CfLqWh4zCiF5WZ, $aB_Ob1WlN9D9Ly = false, $kUN91zm21SnTRebTe = '')
																														{
																														global $UENg1OTT1qn1JDiKJ;
																														$q9kvTl5fCmbzXO = $wb1CfLqWh4zCiF5WZ . ($kUN91zm21SnTRebTe?'-'.md5($kUN91zm21SnTRebTe):'');
																														tAR_IvsnGVJ5v("\nVideo api: $q9kvTl5fCmbzXO , ".($this->AUvXw4XbbY[$q9kvTl5fCmbzXO]?'Cached':'Not in cache').", ".$this->AUvXw4XbbY[$q9kvTl5fCmbzXO]['code']);
																														if(!isset($this->AUvXw4XbbY[$q9kvTl5fCmbzXO]) || !$this->AUvXw4XbbY[$q9kvTl5fCmbzXO]
																														||
																														(strstr($this->AUvXw4XbbY[$q9kvTl5fCmbzXO]['code'],'403')
																														&& !preg_match('#(private|authenticat|authorization|invalid)#si',$this->AUvXw4XbbY[$q9kvTl5fCmbzXO]['content'])
																														)
																														){
																														$_tr=4;
																														while($_tr>0){
																														$fd = $UENg1OTT1qn1JDiKJ->fetch($wb1CfLqWh4zCiF5WZ,
																														0,true, false, '',
																														array('skipip' => true,'anytype'=>true,'addheaders'=>$kUN91zm21SnTRebTe));
																														$_tr--;
																														if(strstr($fd['code'],'200'))$_tr=0;
																														else sleep(3);
																														}
																														$this->AUvXw4XbbY[$q9kvTl5fCmbzXO] = $fd;
																														$this->P4wwgUoZ3394_ODZ();
																														}
																														$BNDGFMwjYZ = $this->AUvXw4XbbY[$q9kvTl5fCmbzXO];
																														if($aB_Ob1WlN9D9Ly && $BNDGFMwjYZ && function_exists('json_decode'))
																														{
																														$BNDGFMwjYZ ['decont'] = json_decode($BNDGFMwjYZ['content'], 1);
																														}
																														return $BNDGFMwjYZ;
																														}
																														function oFZW4Ythm($hO5I1T_wm6Qex)
																														{
																														
																														return $QI85VHfRbRGC_On_B;
																														}
																														function DYKGMBz5gva($urls_completed, &$ZHQ1ImnoZJxgi4p6EK)
																														{
																														global $RVnxlqSo6_kpqxlprQj, $rTRdD_9Y91ccKdyX, $t0clzJiMuvzs1HClOk7, $sm_proc_list, $pWDLRw5FTtL7py52x, $d0A0eoQlstKwVlSp6, $XcNj0gdFq;
																														$giNYdPmsL = $this->NCetweVQi['xs_chlog'];
																														$AmweUGmhFPF = AjcZyvgxP77_7IU(PHl930jhdTpKDZGAz,  'sitemap_xml_tpl.xml');
																														$v4YscK2rLVZqhHeUI = file_get_contents(PHl930jhdTpKDZGAz.$AmweUGmhFPF);
																														preg_match('#^(.*)%URLS_LIST_FROM%(.*)%URLS_LIST_TO%(.*)$#is', $v4YscK2rLVZqhHeUI, $RVnxlqSo6_kpqxlprQj);
																														$RVnxlqSo6_kpqxlprQj[1] = str_replace('www.xml-sitemaps.com', 'www.xml-sitemaps.com ('. a5FCrQFovcxIV7ZT8.')', $RVnxlqSo6_kpqxlprQj[1]);
																														$RVnxlqSo6_kpqxlprQj[1] = str_replace('%GEN_URL%', $this->NCetweVQi['gendom'], $RVnxlqSo6_kpqxlprQj[1]);
																														$dMTqYJrkkBNK5 = preg_replace('#[^\\/]+?\.xml$#', '', $this->NCetweVQi['xs_smurl']);
																														$dMTqYJrkkBNK5 = preg_replace('#^.*\://.*?/#', '/', $dMTqYJrkkBNK5);
																														$RVnxlqSo6_kpqxlprQj[1] = str_replace('%SM_BASE%', $dMTqYJrkkBNK5, $RVnxlqSo6_kpqxlprQj[1]);
																														if($this->NCetweVQi['xs_disable_xsl'])
																														$RVnxlqSo6_kpqxlprQj[1] = preg_replace('#<\?xml-stylesheet.*\?>#', '', $RVnxlqSo6_kpqxlprQj[1]);
																														if($this->NCetweVQi['xs_xsl_custom']){
																														$RVnxlqSo6_kpqxlprQj[1] = str_replace('sitemap.xsl',$this->NCetweVQi['xs_xsl_custom'],$RVnxlqSo6_kpqxlprQj[1]);
																														}else
																														if($this->NCetweVQi['xs_nobrand']){
																														$RVnxlqSo6_kpqxlprQj[1] = str_replace('sitemap.xsl','sitemap_nb.xsl',$RVnxlqSo6_kpqxlprQj[1]);
																														$RVnxlqSo6_kpqxlprQj[1] = preg_replace('#<!-- created.*?>#','',$RVnxlqSo6_kpqxlprQj[1]);
																														}
																														$nd7YBajoTlck9gMuOVz = implode('', file(PHl930jhdTpKDZGAz.'sitemap_ror_tpl.xml'));
																														preg_match('#^(.*)%URLS_LIST_FROM%(.*)%URLS_LIST_TO%(.*)$#is', $nd7YBajoTlck9gMuOVz, $rTRdD_9Y91ccKdyX);
																														$OV3I_GAoENftPDFS2N = implode('', file(PHl930jhdTpKDZGAz.'sitemap_rss_tpl.xml'));
																														preg_match('#^(.*)%URLS_LIST_FROM%(.*)%URLS_LIST_TO%(.*)$#is', $OV3I_GAoENftPDFS2N, $KVWCmKvDNM);
																														$pfnJnsyEyrXqzAFqB3 = implode('', file(PHl930jhdTpKDZGAz.'sitemap_base_tpl.xml'));
																														preg_match('#^(.*)%URLS_LIST_FROM%(.*)%URLS_LIST_TO%(.*)$#is', $pfnJnsyEyrXqzAFqB3, $t0clzJiMuvzs1HClOk7);
																														$this->JOEKzoVvV = $this->NCetweVQi['xs_sm_size']?$this->NCetweVQi['xs_sm_size']:50000;
																														$this->sm_filesplit = $this->NCetweVQi['xs_sm_filesize']?$this->NCetweVQi['xs_sm_filesize']:10;
																														$this->sm_filesplit = max(intval($this->sm_filesplit*1024*1024),2000)-1000;
																														if(isset($this->NCetweVQi['xs_webinfo']) && !$this->NCetweVQi['xs_webinfo'])
																														unset($this->kFmzSZmGvC[0]);
																														if(!$this->NCetweVQi['xs_imginfo'])
																														unset($this->kFmzSZmGvC[1]);
																														if(!$this->NCetweVQi['xs_videoinfo'])
																														unset($this->kFmzSZmGvC[2]);
																														if(!$this->NCetweVQi['xs_newsinfo'])
																														unset($this->kFmzSZmGvC[3]);
																														if(!$this->NCetweVQi['xs_makemob'])
																														unset($this->kFmzSZmGvC[4]);
																														if(!$this->NCetweVQi['xs_rssinfo'])
																														unset($this->kFmzSZmGvC[5]);
																														if(!$this->kFmzSZmGvC)return;
																														$_alang = preg_split('#[\r\n]+#', $this->NCetweVQi['xs_alt_lang']);
																														$_acur = '';
																														$_at = '';
																														$this->tbhM_ZY2QrMG = array('s' => array(), 'r' => array());
																														foreach($_alang as $v){
																														$me = explode(' ', $v);
																														if($me[1]) {
																														$this->tbhM_ZY2QrMG[$_at][$_acur][] = array('t' => 'hreflang', 'l' => $me[0], 'u' => $me[1]);
																														}else {
																														$_at = strstr($v,'*') ? 'r' : 's';
																														$_acur = $v;
																														$this->tbhM_ZY2QrMG[$_at][$_acur] = array();
																														}
																														}
																														$ctime = date('Y-m-d H:i:s');
																														$BJ2hfM0BLH8 = 0;
																														global $xAtJPGJcU7ufADYN1a;
																														$tt = array('<','>');
																														foreach ($tt as $OHVwQNKrsyDCf8rh )
																														$xAtJPGJcU7ufADYN1a[$OHVwQNKrsyDCf8rh] = '&#'.ord($OHVwQNKrsyDCf8rh).';';
																														for($i=0;$i<31;$i++)
																														$xAtJPGJcU7ufADYN1a[chr($i)] = '';
																														
																														$xAtJPGJcU7ufADYN1a[chr(0)] = $xAtJPGJcU7ufADYN1a[chr(10)] = $xAtJPGJcU7ufADYN1a[chr(13)] = '';
																														$xAtJPGJcU7ufADYN1a[' '] = '%20';
																														$pf = 0;
																														
																														$B1p7BCHam3XW = intval($pWDLRw5FTtL7py52x['istart']);
																														$this->Dac2E8mdBqqN($pWDLRw5FTtL7py52x);
																														if($this->NCetweVQi['xs_maketxt'])
																														{
																														$eOXToC2WC0M_pc = $this->RKqSLffk7wVUau['fopen'](w30J4pM_NL10N.$this->cfRaULBmzwIeKwJ11O, $B1p7BCHam3XW?'a':'w');
																														if(!$eOXToC2WC0M_pc)$XcNj0gdFq[] = w30J4pM_NL10N.$this->cfRaULBmzwIeKwJ11O;
																														}
																														if($this->NCetweVQi['xs_makeror'])
																														{
																														$uEQuy7BUg2IT6NlS = TayqlxvkNtkAAUcB35O(F48sx9pih9fQNqddq1A, $B1p7BCHam3XW?'a':'w');
																														$rc = str_replace('%INIT_URL%', $this->NCetweVQi['xs_initurl'], $rTRdD_9Y91ccKdyX[1]);
																														if($uEQuy7BUg2IT6NlS)
																														fJuAFhUG30nRDmZB($uEQuy7BUg2IT6NlS, $rc);
																														else
																														$XcNj0gdFq[] = F48sx9pih9fQNqddq1A;
																														}
																														if($this->NCetweVQi['xs_rssinfo'])
																														{
																														$sznvAGhnJFA8H = $this->uurl_p . basename(cBDgN_b3hkod0Fu);
																														$KiuUbM9S6 = cBDgN_b3hkod0Fu;
																														$WlUKShqVNF = TayqlxvkNtkAAUcB35O($KiuUbM9S6, $B1p7BCHam3XW?'a':'w');
																														$rc = str_replace('%INIT_URL%', $this->NCetweVQi['xs_initurl'], $KVWCmKvDNM[1]);
																														$rc = str_replace('%FEED_TITLE%', ($_rd=$this->NCetweVQi['xs_rsstitle'])?$_rd:'My Feed at '.$this->NCetweVQi['xs_initurl'], $rc);
																														$rc = str_replace('%FEED_DESC%', ($_rd=$this->NCetweVQi['xs_rssdesc'])?$_rd:'My Feed at '.$this->NCetweVQi['xs_initurl'], $rc);
																														$rc = str_replace('%BUILD_DATE%', gmdate('D, d M Y H:i:s +0000'), $rc);
																														$rc = str_replace('%SELF_URL%', $sznvAGhnJFA8H, $rc);
																														if($WlUKShqVNF)
																														fJuAFhUG30nRDmZB($WlUKShqVNF, $rc);
																														else
																														$XcNj0gdFq[] = $KiuUbM9S6;
																														}
																														if($sm_proc_list)
																														foreach($sm_proc_list as $k=>$mahPBbSLSeJuXt0ouk)
																														$sm_proc_list[$k]->gbulQM7mjcqP9ss($this->NCetweVQi, $this->RKqSLffk7wVUau, $this->ZKdlvhdRYtznZAqaYKo);
																														if($this->NCetweVQi['xs_write_delay'])
																														list($tgAhvESZ84, $z4CUELZzb) = explode('|',$this->NCetweVQi['xs_write_delay']);
																														
																														
																														TOz3VYy4To8vIqo('xloop');
																														for($i=$xn=$B1p7BCHam3XW;$i<count($urls_completed);$i++,$xn++)
																														{
																														
																														
																														
																														if($i%100 == 0) {
																														Fnr6FxzsQ7ZnDJP();
																														global $hhVHKMmHq0aYEpBJMP;$hhVHKMmHq0aYEpBJMP->K5DeWy6YJuv8Rk(array('smcreate'=>array('xml',$i,count($urls_completed))));
																														tAR_IvsnGVJ5v(" / $i / ".(time()-$_tm));
																														$_tm=time();
																														mKOCbfdJgbFRvJWVRm(array(
																														'cmd'=> 'info',
																														'id' => 'percprog',
																														'text'=> number_format($i*100/count($urls_completed),0).'%'
																														));
																														}
																														$KM0MQj23iMjrJ = $this->RbQBI3UUmWZDU();
																														if($KM0MQj23iMjrJ && ($i != $B1p7BCHam3XW))
																														{
																														JV7KHTAaxXEYScT457($d0A0eoQlstKwVlSp6,yoZfrgTrTG7vRkYsVD(array('istart'=>$i,'rinfo'=>$this->rKX4vnHo7XuaYI)));
																														}
																														if($this->NCetweVQi['xs_memsave'])
																														{
																														$cu = hr3Ct8y1pYiz_U($urls_completed[$i]);
																														}else
																														$cu = $urls_completed[$i];
																														if(!is_array($cu)) $cu = BS2u9cmxjMg($cu);
																														$l = $this->Hsl90rv_NS6QnJfZ_($cu['link']);
																														$cu['link'] = $l;
																														if(!$l)continue;
																														$t = $this->qDG7zNEAH_8ph($cu['t'], true, true);
																														$d = $this->qDG7zNEAH_8ph($cu['d'] ? $cu['d'] : $cu['t'], true, true);
																														$t2 = $this->q0_UKNHZqX1($cu['t'], false);
																														$d2 = $this->q0_UKNHZqX1($cu['d']?$cu['d']:$cu['t'], false);
																														$H54UPRXXjp = '';
																														if($cu['clm'] && ($Jpp8mAoNZ3z9F = preg_replace('#\s+[a-z]+$#is', '', $cu['clm'])) && strtotime($Jpp8mAoNZ3z9F))
																														$H54UPRXXjp = $Jpp8mAoNZ3z9F;
																														else
																														switch($this->NCetweVQi['xs_lastmod']){
																														case 1:$H54UPRXXjp = $cu['lm']?$cu['lm']:$ctime;break;
																														case 2:$H54UPRXXjp = $ctime;break;
																														case 3:$H54UPRXXjp = $this->NCetweVQi['xs_lastmodtime'];break;
																														}
																														$ohdvRVamH0cb3BspW = $mFj2XSDQgCPOrH5 = false;
																														if($cu['p'])
																														$p = $cu['p'];
																														else
																														{
																														$p = floatval($this->NCetweVQi['xs_priority']);
																														if($this->NCetweVQi['xs_autopriority'])
																														{
																														$p = $p*pow($this->NCetweVQi['xs_descpriority']?$this->NCetweVQi['xs_descpriority']:0.8,intval($cu['o']));
																														if($this->sH0gDPyLZD3QpFBpP9b)
																														{
																														$ohdvRVamH0cb3BspW = true;
																														$mFj2XSDQgCPOrH5 = ($this->sH0gDPyLZD3QpFBpP9b&&!isset($this->sH0gDPyLZD3QpFBpP9b[$cu['link']]))||$this->jIYikA9ng[$cu['link']];
																														if($mFj2XSDQgCPOrH5)
																														$p=0.95;
																														}
																														$p = max(0.0001,min($p,1.0));
																														$p = @number_format($p, 4);
																														}
																														if(!$this->NCetweVQi['xs_priority'])
																														$p = '';
																														}
																														if($H54UPRXXjp){
																														$H54UPRXXjp = strtotime($H54UPRXXjp);
																														$H54UPRXXjp = gmdate('Y-m-d\TH:i:s+00:00',$H54UPRXXjp);
																														}
																														$f = $cu['f']?$cu['f']:$this->NCetweVQi['xs_freq'];
																														$_al = array();
																														if($this->tbhM_ZY2QrMG['s'][$l])
																														$_al = $this->tbhM_ZY2QrMG['s'][$l];
																														else
																														{
																														foreach($this->tbhM_ZY2QrMG['r'] as $_aurl => $_ll)
																														if(preg_match('#'.$_aurl.'#i', $l, $lm)) {
																														$_al = $_ll;
																														foreach($_al as $_k=>$_v)
																														$_al[$_k]['u'] = $this->Hsl90rv_NS6QnJfZ_(preg_replace('#'.$_aurl.'#', $_v['u'], $l));
																														break;
																														}
																														}
																														if(!$_al)
																														$_al = $cu['hl'];
																														if($_al)
																														foreach($_al as $_k=>$_v)
																														$_al[$_k]['u'] = $this->Hsl90rv_NS6QnJfZ_($_v['u']);
																														$GGrK70Kwt = array(
																														'URL'=>$l,
																														'TITLE'=>$t,
																														'DESC'=>($d),
																														'PERIOD'=>$f,
																														'LASTMOD'=>$H54UPRXXjp,
																														'ORDER'=>$cu['o'],
																														'PRIORITY'=>$p,
																														'ALTLANG' => $_al
																														);
																														if($this->NCetweVQi['xs_makemob'])
																														{
																														if(!$this->NCetweVQi['xs_mobileincmask'] ||
																														preg_match('#'.str_replace(' ', '|', preg_quote($this->NCetweVQi['xs_mobileincmask'],'#')).'#',$GGrK70Kwt['URL']))
																														$this->vGabrFdNEZXhpoi7tS0(array_merge($GGrK70Kwt, array('ismob'=>true)), $RVnxlqSo6_kpqxlprQj[2], 4);
																														}
																														
																														
																														$this->vGabrFdNEZXhpoi7tS0($GGrK70Kwt, $RVnxlqSo6_kpqxlprQj[2], 0);
																														
																														
																														if($this->NCetweVQi['xs_maketxt'] && $eOXToC2WC0M_pc)
																														$this->RKqSLffk7wVUau['fwrite']($eOXToC2WC0M_pc, $cu['link']."\n");
																														if($sm_proc_list)
																														foreach($sm_proc_list as $mahPBbSLSeJuXt0ouk)
																														$mahPBbSLSeJuXt0ouk->xXvVsjkUrpk4FkdTU6j($GGrK70Kwt);
																														if($this->NCetweVQi['xs_makeror'] && $uEQuy7BUg2IT6NlS)
																														if(!$this->NCetweVQi['xs_ror_max'] ||
																														($i < $this->NCetweVQi['xs_ror_max']))
																														{
																														$tt = $t2;
																														$dd = $d2;
																														if($this->NCetweVQi['xs_ror_unique']){
																														$t0 = $tt;$d0=$dd;
																														while($tiMRiuTjxlTfA=$ai[md5('t'.$tt)]++){
																														$tt=$t0.' '.$tiMRiuTjxlTfA;
																														}
																														while($tiMRiuTjxlTfA=$ai[md5('d'.$dd)]++){
																														$dd=$d0.' '.$tiMRiuTjxlTfA;
																														}
																														}
																														$GGrK70Kwt['TITLE'] = $tt;
																														$GGrK70Kwt['DESC'] = $dd;
																														fJuAFhUG30nRDmZB($uEQuy7BUg2IT6NlS, $this->ZKdlvhdRYtznZAqaYKo->z9RtV_86tPe($rTRdD_9Y91ccKdyX[2],$GGrK70Kwt));
																														}
																														if($giNYdPmsL) {
																														if(!isset($this->sH0gDPyLZD3QpFBpP9b[$cu['link']]) &&
																														count($this->uff0w2sMZc2)<$this->se9WZ0V8f4)
																														$this->uff0w2sMZc2[$cu['link']]++;
																														}
																														unset($this->sH0gDPyLZD3QpFBpP9b[$cu['link']]);
																														}
																														
																														TOz3VYy4To8vIqo('xloop',1);
																														$this->Lg4LZr_c61MnAxk();
																														if($this->NCetweVQi['xs_maketxt'])
																														{
																														$this->RKqSLffk7wVUau['fclose']($eOXToC2WC0M_pc);
																														@chmod(w30J4pM_NL10N.$this->cfRaULBmzwIeKwJ11O, 0666);
																														}
																														if($this->NCetweVQi['xs_makeror'])
																														{
																														if($uEQuy7BUg2IT6NlS)
																														fJuAFhUG30nRDmZB($uEQuy7BUg2IT6NlS, $rTRdD_9Y91ccKdyX[3]);
																														fclose($uEQuy7BUg2IT6NlS);
																														}
																														if($this->NCetweVQi['xs_rssinfo'])
																														{
																														if($WlUKShqVNF)
																														fJuAFhUG30nRDmZB($WlUKShqVNF, $KVWCmKvDNM[3]);
																														fclose($WlUKShqVNF);
																														
																														}
																														if($sm_proc_list)
																														foreach($sm_proc_list as $mahPBbSLSeJuXt0ouk)
																														$mahPBbSLSeJuXt0ouk->WVMyPY9m41kdDDlAqDn();
																														JV7KHTAaxXEYScT457($d0A0eoQlstKwVlSp6,yoZfrgTrTG7vRkYsVD(array('done'=>true)));
																														mKOCbfdJgbFRvJWVRm(array('cmd'=> 'info','id' => 'percprog',''));
																														}
																														function cXgWFRIZn0c($AlKFygqsa0zd, $Wap4seYoMvS, $cfRaULBmzwIeKwJ11O = '')
																														{
																														for($i=0;file_exists($sf=$AlKFygqsa0zd.efCnubSjJv($i,$Wap4seYoMvS).$cfRaULBmzwIeKwJ11O);$i++)
																														de5FLAUWTohCIUr2do($sf);
																														}
																														function jmZ0yLw7GHD9Dvsi($Wap4seYoMvS)
																														{
																														if($this->NCetweVQi['xs_compress']!=1) {
																														$this->cXgWFRIZn0c(uzAGLJ0Y3V,$Wap4seYoMvS);
																														$this->cXgWFRIZn0c($this->WWn8KZwxnLWklnDp,$Wap4seYoMvS);
																														}
																														if($this->NCetweVQi['xs_compress']>0) {
																														$this->cXgWFRIZn0c(uzAGLJ0Y3V,$Wap4seYoMvS,'.gz');
																														$this->cXgWFRIZn0c($this->WWn8KZwxnLWklnDp,$Wap4seYoMvS,'.gz');
																														}
																														}
																														function FHKj5L6kXW3a($Wap4seYoMvS) {
																														if(file_exists($Wap4seYoMvS) && !strstr($Wap4seYoMvS, '.gz')){
																														$cn = file_get_contents($Wap4seYoMvS);
																														if(JV7KHTAaxXEYScT457($Wap4seYoMvS, $cn, '', true)){
																														de5FLAUWTohCIUr2do($Wap4seYoMvS);
																														}
																														}
																														}
																														function iJF_O75zro($Za5UOsM7Dgf8KSG8, $bY8hm5uxUw)
																														{
																														global $XcNj0gdFq;
																														$wUnMpD42LH = false;
																														if(!@copy($Za5UOsM7Dgf8KSG8,$bY8hm5uxUw))
																														{
																														if($this->NCetweVQi['xs_filewmove'] && file_exists($bY8hm5uxUw) ){
																														de5FLAUWTohCIUr2do($bY8hm5uxUw);
																														}
																														if($cn = @TayqlxvkNtkAAUcB35O($bY8hm5uxUw, 'w')){
																														@fJuAFhUG30nRDmZB($cn, file_get_contents($Za5UOsM7Dgf8KSG8));
																														@fclose($cn);
																														}else
																														if(file_exists($Za5UOsM7Dgf8KSG8))
																														{
																														$XcNj0gdFq[] = $bY8hm5uxUw;
																														$wUnMpD42LH = true;
																														}
																														}
																														
																														@chmod($Za5UOsM7Dgf8KSG8, 0666);
																														return $wUnMpD42LH;
																														}
																														function pHpBVXxYyBEKOLn23($Wap4seYoMvS, $KDl67XHL__skVVC = array())
																														{
																														tAR_IvsnGVJ5v("Copy sitemap $Wap4seYoMvS\n",2);
																														$gp = ($this->NCetweVQi['xs_compress']>0) ? '.gz' : '';
																														for($i=0;file_exists(uzAGLJ0Y3V.($sf=efCnubSjJv($i,$Wap4seYoMvS).$this->cfRaULBmzwIeKwJ11O));$i++){
																														tAR_IvsnGVJ5v( "...$sf\n",2);
																														if($gp) {
																														$cn = file_get_contents(uzAGLJ0Y3V.$sf);
																														if(strstr($cn, '<sitemapindex'))
																														$cn = str_replace('.xml</loc>', '.xml.gz</loc>', $cn);
																														JV7KHTAaxXEYScT457(uzAGLJ0Y3V.$sf, $cn, '', true);
																														$this->iJF_O75zro(uzAGLJ0Y3V.$sf.$gp,$this->WWn8KZwxnLWklnDp.$sf.$gp);
																														
																														}
																														$Txchl3_LBanezuuwwd = (count($KDl67XHL__skVVC)>1) && ($i==0);
																														if(!$Txchl3_LBanezuuwwd && $gp && $this->NCetweVQi['xs_compress_optimize']){
																														
																														de5FLAUWTohCIUr2do($this->WWn8KZwxnLWklnDp.$sf);
																														de5FLAUWTohCIUr2do(uzAGLJ0Y3V.$sf);
																														}else {
																														$this->iJF_O75zro(uzAGLJ0Y3V.$sf,$this->WWn8KZwxnLWklnDp.$sf);
																														}
																														}
																														}
																														function L34eQwTww7Wadt2E($Wap4seYoMvS, $p9Edm32HE = -1, $VtZD5tqSJ5YW9LiQd = '', $mxmrLVvxnFIvt3QNg = 0)
																														{
																														$cn = '';
																														$_fold = (strstr($Wap4seYoMvS,'/')||strstr($Wap4seYoMvS,'\\')) ? '' : uzAGLJ0Y3V ;
																														$gp = ($this->NCetweVQi['xs_compress']>0) ? '.gz' : '';
																														$_fapp = $this->NCetweVQi['xs_compress_optimize']?$gp:($mxmrLVvxnFIvt3QNg ?  '' : $gp);
																														for($i=0;file_exists($sf=$_fold.efCnubSjJv($i,$Wap4seYoMvS).$_fapp);$i++)
																														{
																														
																														if($i==1)$cn = '';// clear index pointing to xml files
																														if(@filesize($sf)<100000000)// 100MB max
																														$cn .= $_fapp?implode('',gzfile($sf)):BU6hTbtN56($sf);
																														if($i>200)break;
																														}
																														$yv5u8LLUm = array(
																														array('loc', 'news:publication_date', 'priority'),
																														array('link', 'pubDate', ''), //rss
																														);
																														$mt = $yv5u8LLUm[$mxmrLVvxnFIvt3QNg];
																														preg_match_all('#<'.$mt[0].'>(.*?)</'.$mt[0].'>'.
																														(($p9Edm32HE>=0) ? '.*?<'.$mt[1].'>(.*?)</'.$mt[1].'>' : '').
																														(($VtZD5tqSJ5YW9LiQd && $mt[2])? '.*?<'.$mt[2].'>(.*?)</'.$mt[2].'>' : '').
																														'#is',$cn,$um);
																														$al = array();
																														foreach($um[1] as $i=>$l)
																														{
																														if($VtZD5tqSJ5YW9LiQd){
																														if(!strstr($l, $VtZD5tqSJ5YW9LiQd))
																														continue;
																														$l = substr($l, strlen($VtZD5tqSJ5YW9LiQd));
																														}
																														if(!$l)continue;
																														if($p9Edm32HE<=0) {
																														if($um[2][$i])
																														$al[$l] = $um[2][$i];
																														else
																														$al[$l]++;
																														}
																														else
																														if(time()-strtotime($um[2][$i])<=$p9Edm32HE*24*3600)
																														$al[$l] = $um[2][$i];
																														}
																														return $al;
																														}
																														function Z5L_2zdRy1ossQ($Wap4seYoMvS, $ydeDUbh1NuRR)
																														{
																														$cn = '';
																														$_fold = (strstr($Wap4seYoMvS,'/')||strstr($Wap4seYoMvS,'\\')) ? '' : uzAGLJ0Y3V ;
																														$gp = ($this->NCetweVQi['xs_compress']>0) ? '.gz' : '';
																														$_fapp = ($mxmrLVvxnFIvt3QNg ?  '' : $gp);
																														for($i=0;file_exists($sf=$_fold.efCnubSjJv($i,$Wap4seYoMvS).$_fapp);$i++)
																														{
																														
																														if(@filesize($sf)<100000000)// 100MB max
																														$cn .= $_fapp?implode('',gzfile($sf)):BU6hTbtN56($sf);
																														if($i>200)break;
																														}
																														preg_match_all('#<url[^>]*>(.*?)</url>#is',$cn,$um);
																														$al = array();
																														foreach($um[1] as $i=>$l)
																														{
																														if(preg_match('#<loc[^>]*>(.*?)</loc>#is',$l,$ANXRLscUke))
																														{
																														$v4IeCaD2SMJw0AIN3xe = array();
																														preg_match_all('#<'.$ydeDUbh1NuRR.'[^>]*>(.*?)</'.$ydeDUbh1NuRR.'>#is',$l,$Xvyj7TQMbl);
																														foreach($Xvyj7TQMbl[1] as $i=>$l2)
																														{
																														$v4IeCaD2SMJw0AIN3xe[$l2]++;
																														}
																														if($v4IeCaD2SMJw0AIN3xe){
																														$al[$ANXRLscUke[1]] = $v4IeCaD2SMJw0AIN3xe;
																														}
																														}
																														}
																														return $al;
																														}
																														}
																														global $cD5HD5wYmq8kXUkOT;
																														$cD5HD5wYmq8kXUkOT = new XMLCreator();
																														}
																														



































































































