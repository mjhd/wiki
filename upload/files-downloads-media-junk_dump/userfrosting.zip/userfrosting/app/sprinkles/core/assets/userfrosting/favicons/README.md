# Default Favicons for UserFrosting

There are a bewildering number of device- and vendor-specific favicons these days.  And, the specifications are changing constantly as new devices with new screen resolutions are released, and old devices and operating systems are retired.

We recommend the [Favicon Cheat Sheet](https://github.com/audreyr/favicon-cheat-sheet) as a way to stay up-to-date with current specifications and best practices regarding favicons.

To automatically generate favicons for a wide variety of devices, platforms, and operating systems, we suggest https://realfavicongenerator.net.  The default icons you see in this directory were generated using this site.
