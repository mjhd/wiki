<?php

    /**
     * Sample site configuration file for UserFrosting.  You should definitely set these values!
     *
     */
    return [
        'address_book' => [
            'admin' => [
                'name'  => 'Squawkbot'
            ]
        ],
        'debug' => [
            'smtp' => true
        ],
        'site' => [
            'registration' => [
                'enabled' => false
            ],
            'author'    =>      'David Attenborough',
            'title'     =>      'Owl Fancy',
            'menu' => '<nav><ul></ul></nav>',
            // URLs
            'uri' => [
                'author' => 'https://attenboroughsreef.com'
            ]
        ],
        'php' => [
            'timezone' => 'America/Los_Angeles'
        ]
    ];