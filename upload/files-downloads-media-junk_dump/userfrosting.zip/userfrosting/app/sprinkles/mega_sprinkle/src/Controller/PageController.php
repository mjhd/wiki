<?php

namespace UserFrosting\Sprinkle\Mega_Sprinkle\Controller;

use UserFrosting\Sprinkle\Core\Controller\SimpleController;

class PageController extends SimpleController
{
    public function pageAdmin($request, $response, $args)
    {
        return $this->ci->view->render($response, 'pages/admin.html.twig');
    }
    public function pageUsers($request, $response, $args)
    {
        return $this->ci->view->render($response, 'pages/home.html.twig');
    }
}