<?php

$app->get('/home', 'UserFrosting\Sprinkle\Mega_Sprinkle\Controller\PageController:pageUsers')
    ->setName('home')
    ->add('authGuard');
$app->get('/_admin', 'UserFrosting\Sprinkle\Mega_Sprinkle\Controller\PageController:pageAdmin')
//    ->setName('_admin')
    ->add('authGuard');
//$app->get('/members_insecure', 'UserFrosting\Sprinkle\Test\Controller\PageController:pageMembers');