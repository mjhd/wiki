-- MySQL dump 10.15  Distrib 10.0.38-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: userfrosting
-- ------------------------------------------------------
-- Server version	10.0.38-MariaDB-wsrep

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'An identifier used to track the type of activity.',
  `occurred_at` timestamp NULL DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `activities_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=365 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (1,'192.168.150.100',1,'sign_in','2019-01-29 02:18:46','User nowadmin signed in.'),(2,'192.168.150.100',1,'update_profile_settings','2019-01-29 02:19:09','User nowadmin updated their profile settings.'),(5,'192.168.150.100',1,'sign_in','2019-01-29 18:12:13','User nowadmin signed in.'),(19,'192.168.150.100',1,'sign_out','2019-01-29 18:21:26','User nowadmin signed out.'),(20,'192.168.150.100',1,'sign_in','2019-01-29 18:26:07','User nowadmin signed in.'),(106,'192.168.150.100',1,'sign_in','2019-01-29 23:47:20','User nowadmin signed in.'),(109,'192.168.150.100',1,'sign_in','2019-01-31 00:19:36','User nowadmin signed in.'),(130,'192.168.150.100',1,'sign_in','2019-01-31 01:45:46','User nowadmin signed in.'),(134,'192.168.150.100',1,'account_update_info','2019-01-31 01:49:52','User nowadmin updated basic account info for user nowadmin.'),(135,'192.168.150.135',1,'sign_in','2019-02-11 19:19:46','User nowadmin signed in.'),(137,'192.168.150.135',1,'sign_in','2019-02-19 19:31:37','User nowadmin signed in.'),(138,'192.168.150.135',1,'sign_in','2019-03-01 19:58:30','User nowadmin signed in.'),(139,'192.168.150.135',1,'sign_in','2019-03-04 23:17:32','User nowadmin signed in.'),(140,'192.168.150.135',1,'sign_in','2019-03-12 01:02:51','User nowadmin signed in.'),(148,'192.168.150.135',1,'sign_in','2019-03-12 23:37:06','User nowadmin signed in.'),(149,'192.168.150.102',1,'sign_in','2019-07-02 17:32:32','User nowadmin signed in.'),(211,'192.168.150.102',1,'sign_out','2019-07-03 00:44:07','User nowadmin signed out.'),(212,'192.168.150.102',1,'sign_in','2019-07-03 00:44:14','User nowadmin signed in.'),(215,'192.168.150.102',1,'sign_out','2019-07-03 01:16:29','User nowadmin signed out.'),(216,'192.168.150.102',2,'sign_in','2019-07-03 01:16:48','User test signed in.'),(217,'192.168.150.102',1,'sign_in','2019-07-03 21:22:43','User nowadmin signed in.'),(218,'192.168.150.102',1,'sign_in','2019-07-08 14:33:41','User nowadmin signed in.'),(219,'192.168.150.102',2,'sign_in','2019-07-08 14:33:41','User test signed in.'),(220,'192.168.150.102',2,'sign_out','2019-07-08 14:35:09','User test signed out.'),(221,'192.168.150.102',2,'sign_in','2019-07-09 23:25:20','User test signed in.'),(222,'192.168.150.102',2,'sign_out','2019-07-09 23:27:31','User test signed out.'),(223,'192.168.150.102',1,'sign_in','2019-07-09 23:27:37','User nowadmin signed in.'),(224,'192.168.150.102',1,'sign_out','2019-07-09 23:28:53','User nowadmin signed out.'),(225,'192.168.150.102',2,'sign_in','2019-07-09 23:29:21','User test signed in.'),(226,'192.168.150.102',2,'sign_out','2019-07-09 23:30:43','User test signed out.'),(227,'192.168.150.102',1,'sign_in','2019-07-10 00:15:35','User nowadmin signed in.'),(228,'192.168.150.15',2,'sign_in','2019-07-10 00:25:33','User test signed in.'),(229,'192.168.150.15',2,'sign_out','2019-07-10 00:47:47','User test signed out.'),(230,'192.168.150.15',1,'sign_in','2019-07-10 00:47:58','User nowadmin signed in.'),(231,'192.168.150.102',1,'sign_in','2019-07-10 19:25:31','User nowadmin signed in.'),(233,'192.168.150.102',1,'sign_in','2019-07-11 17:05:14','User nowadmin signed in.'),(234,'192.168.150.102',2,'sign_in','2019-07-11 17:05:32','User test signed in.'),(235,'192.168.150.103',1,'sign_in','2019-08-05 19:02:26','User nowadmin signed in.'),(236,'192.168.150.103',1,'sign_in','2019-08-06 19:05:23','User nowadmin signed in.'),(237,'192.168.150.103',1,'sign_in','2019-08-19 15:10:10','User nowadmin signed in.'),(238,'192.168.150.103',1,'sign_in','2019-08-19 15:19:51','User nowadmin signed in.'),(239,'192.168.150.103',1,'sign_out','2019-08-19 15:20:23','User nowadmin signed out.'),(240,'192.168.150.103',2,'sign_in','2019-08-19 15:20:41','User test signed in.'),(241,'192.168.150.103',2,'sign_in','2019-08-19 17:53:52','User test signed in.'),(242,'192.168.150.103',2,'sign_out','2019-08-19 19:51:03','User test signed out.'),(243,'192.168.150.103',2,'sign_in','2019-08-19 19:51:12','User test signed in.'),(244,'192.168.150.103',2,'sign_out','2019-08-19 19:52:35','User test signed out.'),(245,'192.168.150.103',2,'sign_in','2019-08-19 19:52:53','User test signed in.'),(246,'192.168.150.103',2,'sign_in','2019-08-19 20:54:15','User test signed in.'),(247,'192.168.150.103',2,'sign_out','2019-08-19 20:54:57','User test signed out.'),(248,'192.168.150.103',1,'sign_in','2019-08-19 20:55:01','User nowadmin signed in.'),(249,'192.168.150.103',2,'sign_out','2019-08-19 21:55:00','User test signed out.'),(250,'192.168.150.103',2,'sign_in','2019-08-19 21:55:05','User test signed in.'),(251,'192.168.150.103',2,'sign_out','2019-08-19 21:57:07','User test signed out.'),(252,'192.168.150.103',2,'sign_in','2019-08-19 21:57:10','User test signed in.'),(253,'192.168.150.103',2,'sign_out','2019-08-19 21:57:28','User test signed out.'),(254,'192.168.150.103',2,'sign_in','2019-08-19 21:57:30','User test signed in.'),(255,'192.168.150.103',1,'sign_out','2019-08-19 21:57:57','User nowadmin signed out.'),(256,'192.168.150.103',1,'sign_in','2019-08-19 21:58:02','User nowadmin signed in.'),(257,'192.168.150.103',2,'sign_in','2019-08-20 14:03:09','User test signed in.'),(258,'192.168.150.103',1,'sign_in','2019-08-20 14:03:42','User nowadmin signed in.'),(259,'192.168.150.103',2,'sign_out','2019-08-20 14:05:12','User test signed out.'),(260,'192.168.150.103',2,'sign_in','2019-08-20 14:08:06','User test signed in.'),(261,'192.168.150.103',2,'sign_out','2019-08-20 14:26:31','User test signed out.'),(262,'192.168.150.103',2,'sign_in','2019-08-20 14:26:39','User test signed in.'),(263,'192.168.150.103',1,'sign_out','2019-08-20 14:30:34','User nowadmin signed out.'),(264,'192.168.150.103',1,'sign_in','2019-08-20 14:30:39','User nowadmin signed in.'),(265,'192.168.150.103',1,'sign_out','2019-08-20 14:31:00','User nowadmin signed out.'),(266,'192.168.150.103',1,'sign_in','2019-08-20 14:31:04','User nowadmin signed in.'),(267,'192.168.150.103',1,'sign_out','2019-08-20 14:37:35','User nowadmin signed out.'),(268,'192.168.150.103',1,'sign_in','2019-08-20 14:37:39','User nowadmin signed in.'),(269,'192.168.150.103',2,'sign_out','2019-08-20 14:37:48','User test signed out.'),(270,'192.168.150.103',2,'sign_in','2019-08-20 14:37:51','User test signed in.'),(271,'192.168.150.103',1,'sign_out','2019-08-20 14:40:36','User nowadmin signed out.'),(272,'192.168.150.103',1,'sign_in','2019-08-20 14:40:40','User nowadmin signed in.'),(273,'192.168.150.103',2,'sign_out','2019-08-20 14:40:45','User test signed out.'),(274,'192.168.150.103',2,'sign_in','2019-08-20 14:40:48','User test signed in.'),(275,'192.168.150.103',2,'sign_out','2019-08-20 14:43:22','User test signed out.'),(276,'192.168.150.103',1,'sign_out','2019-08-20 14:43:28','User nowadmin signed out.'),(277,'192.168.150.103',1,'sign_in','2019-08-20 14:43:31','User nowadmin signed in.'),(278,'192.168.150.103',2,'sign_in','2019-08-20 14:50:49','User test signed in.'),(279,'192.168.150.103',2,'sign_out','2019-08-20 14:50:56','User test signed out.'),(280,'192.168.150.103',2,'sign_in','2019-08-20 14:50:59','User test signed in.'),(281,'192.168.150.103',2,'sign_out','2019-08-20 14:58:04','User test signed out.'),(282,'192.168.150.103',2,'sign_in','2019-08-20 14:58:08','User test signed in.'),(283,'192.168.150.103',2,'sign_out','2019-08-20 14:58:49','User test signed out.'),(284,'192.168.150.103',2,'sign_in','2019-08-20 14:58:51','User test signed in.'),(285,'192.168.150.103',2,'sign_out','2019-08-20 14:59:18','User test signed out.'),(286,'192.168.150.103',2,'sign_in','2019-08-20 14:59:21','User test signed in.'),(287,'192.168.150.103',1,'sign_out','2019-08-20 14:59:56','User nowadmin signed out.'),(288,'192.168.150.103',1,'sign_in','2019-08-20 15:00:00','User nowadmin signed in.'),(289,'192.168.150.103',1,'sign_out','2019-08-20 15:01:19','User nowadmin signed out.'),(290,'192.168.150.103',1,'sign_in','2019-08-20 15:01:24','User nowadmin signed in.'),(291,'192.168.150.103',2,'sign_out','2019-08-20 15:01:28','User test signed out.'),(292,'192.168.150.103',2,'sign_in','2019-08-20 15:01:32','User test signed in.'),(293,'192.168.150.103',2,'sign_out','2019-08-20 15:11:44','User test signed out.'),(294,'192.168.150.103',2,'sign_in','2019-08-20 15:11:50','User test signed in.'),(295,'192.168.150.103',2,'sign_out','2019-08-20 15:12:04','User test signed out.'),(296,'192.168.150.103',2,'sign_in','2019-08-20 15:12:10','User test signed in.'),(297,'192.168.150.103',2,'sign_out','2019-08-20 15:15:30','User test signed out.'),(298,'192.168.150.103',1,'sign_out','2019-08-20 15:20:30','User nowadmin signed out.'),(299,'192.168.150.103',1,'sign_in','2019-08-20 15:20:33','User nowadmin signed in.'),(300,'192.168.150.103',2,'sign_in','2019-08-20 15:29:35','User test signed in.'),(301,'192.168.150.103',1,'sign_out','2019-08-20 16:38:42','User nowadmin signed out.'),(302,'192.168.150.103',1,'sign_in','2019-08-20 16:38:45','User nowadmin signed in.'),(303,'192.168.150.103',2,'sign_out','2019-08-20 16:41:29','User test signed out.'),(304,'192.168.150.103',2,'sign_in','2019-08-20 16:41:32','User test signed in.'),(305,'192.168.150.103',2,'sign_out','2019-08-20 16:44:23','User test signed out.'),(306,'192.168.150.103',2,'sign_in','2019-08-20 16:44:27','User test signed in.'),(307,'192.168.150.103',2,'sign_out','2019-08-20 16:49:02','User test signed out.'),(308,'192.168.150.103',2,'sign_in','2019-08-20 17:06:46','User test signed in.'),(309,'192.168.150.103',1,'sign_out','2019-08-20 17:08:01','User nowadmin signed out.'),(310,'192.168.150.103',1,'sign_in','2019-08-20 17:08:04','User nowadmin signed in.'),(311,'192.168.150.103',1,'sign_out','2019-08-20 17:08:14','User nowadmin signed out.'),(312,'192.168.150.103',1,'sign_in','2019-08-20 17:08:18','User nowadmin signed in.'),(313,'192.168.150.103',1,'sign_out','2019-08-20 17:08:34','User nowadmin signed out.'),(314,'192.168.150.103',1,'sign_in','2019-08-20 17:08:37','User nowadmin signed in.'),(315,'192.168.150.103',1,'sign_out','2019-08-20 17:10:03','User nowadmin signed out.'),(316,'192.168.150.103',1,'sign_in','2019-08-20 17:10:06','User nowadmin signed in.'),(317,'192.168.150.103',1,'sign_out','2019-08-20 17:11:10','User nowadmin signed out.'),(318,'192.168.150.103',1,'sign_in','2019-08-20 17:11:14','User nowadmin signed in.'),(319,'192.168.150.103',1,'sign_out','2019-08-20 17:11:59','User nowadmin signed out.'),(320,'192.168.150.103',1,'sign_in','2019-08-20 17:12:16','User nowadmin signed in.'),(321,'192.168.150.103',1,'sign_out','2019-08-20 17:12:23','User nowadmin signed out.'),(322,'192.168.150.103',1,'sign_in','2019-08-20 17:12:27','User nowadmin signed in.'),(323,'192.168.150.103',2,'sign_out','2019-08-20 17:13:15','User test signed out.'),(324,'192.168.150.103',2,'sign_in','2019-08-20 17:13:18','User test signed in.'),(325,'192.168.150.103',1,'sign_out','2019-08-20 17:13:55','User nowadmin signed out.'),(326,'192.168.150.103',1,'sign_in','2019-08-20 17:13:59','User nowadmin signed in.'),(327,'192.168.150.103',1,'sign_out','2019-08-20 17:14:39','User nowadmin signed out.'),(328,'192.168.150.103',1,'sign_in','2019-08-20 17:14:42','User nowadmin signed in.'),(329,'192.168.150.103',1,'sign_out','2019-08-20 17:39:45','User nowadmin signed out.'),(330,'192.168.150.103',1,'sign_in','2019-08-20 17:41:05','User nowadmin signed in.'),(331,'192.168.150.103',2,'sign_out','2019-08-20 17:41:11','User test signed out.'),(332,'192.168.150.103',2,'sign_in','2019-08-20 17:41:14','User test signed in.'),(333,'192.168.150.103',2,'sign_out','2019-08-20 17:41:58','User test signed out.'),(334,'192.168.150.103',2,'sign_in','2019-08-20 17:42:01','User test signed in.'),(335,'192.168.150.103',1,'sign_out','2019-08-20 17:46:24','User nowadmin signed out.'),(336,'192.168.150.103',1,'sign_in','2019-08-20 17:46:28','User nowadmin signed in.'),(337,'192.168.150.103',1,'sign_out','2019-08-20 17:49:13','User nowadmin signed out.'),(338,'192.168.150.103',1,'sign_in','2019-08-20 17:49:17','User nowadmin signed in.'),(339,'192.168.150.103',2,'sign_out','2019-08-20 18:45:24','User test signed out.'),(340,'192.168.150.103',2,'sign_in','2019-08-20 18:45:27','User test signed in.'),(341,'192.168.150.103',2,'sign_out','2019-08-20 18:46:15','User test signed out.'),(342,'192.168.150.103',2,'sign_in','2019-08-20 18:46:17','User test signed in.'),(343,'192.168.150.103',2,'sign_out','2019-08-20 18:47:07','User test signed out.'),(344,'192.168.150.103',2,'sign_in','2019-08-20 18:51:56','User test signed in.'),(345,'192.168.150.103',1,'sign_out','2019-08-20 18:56:06','User nowadmin signed out.'),(346,'192.168.150.103',1,'sign_in','2019-08-20 18:56:13','User nowadmin signed in.'),(347,'192.168.150.103',1,'sign_out','2019-08-20 18:56:20','User nowadmin signed out.'),(348,'192.168.150.103',1,'sign_in','2019-08-20 18:59:45','User nowadmin signed in.'),(349,'192.168.150.103',1,'sign_out','2019-08-20 19:00:37','User nowadmin signed out.'),(350,'192.168.150.103',1,'sign_in','2019-08-20 19:00:42','User nowadmin signed in.'),(351,'192.168.150.103',2,'sign_out','2019-08-20 19:00:48','User test signed out.'),(352,'192.168.150.103',2,'sign_in','2019-08-20 19:00:52','User test signed in.'),(353,'192.168.150.103',2,'sign_out','2019-08-20 19:01:24','User test signed out.'),(354,'192.168.150.103',2,'sign_in','2019-08-20 19:01:29','User test signed in.'),(355,'192.168.150.103',2,'sign_out','2019-08-20 19:01:33','User test signed out.'),(356,'192.168.150.103',2,'sign_in','2019-08-20 19:01:36','User test signed in.'),(357,'192.168.150.103',2,'sign_out','2019-08-20 19:26:28','User test signed out.'),(358,'192.168.150.103',2,'sign_in','2019-08-20 19:26:34','User test signed in.'),(359,'192.168.150.103',2,'sign_in','2019-08-20 21:46:53','User test signed in.'),(360,'192.168.150.103',1,'sign_in','2019-08-20 21:48:13','User nowadmin signed in.'),(361,'192.168.150.103',1,'sign_out','2019-08-20 21:51:32','User nowadmin signed out.'),(362,'192.168.150.103',1,'sign_in','2019-08-20 21:51:37','User nowadmin signed in.'),(363,'192.168.150.103',2,'sign_out','2019-08-20 21:51:50','User test signed out.'),(364,'192.168.150.103',2,'sign_in','2019-08-20 21:51:53','User test signed in.');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `icon` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'fa fa-user' COMMENT 'The icon representing users in this group.',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_slug_unique` (`slug`),
  KEY `groups_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'terran','Terran','The terrans are a young species with psionic potential. The terrans of the Koprulu sector descend from the survivors of a disastrous 23rd century colonization mission from Earth.','sc sc-terran','2019-01-28 21:07:59','2019-01-28 21:07:59'),(2,'zerg','Zerg','Dedicated to the pursuit of genetic perfection, the zerg relentlessly hunt down and assimilate advanced species across the galaxy, incorporating useful genetic code into their own.','sc sc-zerg','2019-01-28 21:07:59','2019-01-28 21:07:59'),(3,'protoss','Protoss','The protoss, a.k.a. the Firstborn, are a sapient humanoid race native to Aiur. Their advanced technology complements and enhances their psionic mastery.','sc sc-protoss','2019-01-28 21:07:59','2019-01-28 21:07:59');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sprinkle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'core','\\UserFrosting\\Sprinkle\\Core\\Database\\Migrations\\v400\\SessionsTable',1,'2019-01-28 21:07:57','2019-01-28 21:07:57'),(2,'core','\\UserFrosting\\Sprinkle\\Core\\Database\\Migrations\\v400\\ThrottlesTable',1,'2019-01-28 21:07:57','2019-01-28 21:07:57'),(3,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\ActivitiesTable',1,'2019-01-28 21:07:58','2019-01-28 21:07:58'),(4,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\GroupsTable',1,'2019-01-28 21:07:59','2019-01-28 21:07:59'),(5,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\PasswordResetsTable',1,'2019-01-28 21:07:59','2019-01-28 21:07:59'),(6,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\PermissionRolesTable',1,'2019-01-28 21:08:00','2019-01-28 21:08:00'),(7,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\RolesTable',1,'2019-01-28 21:08:01','2019-01-28 21:08:01'),(8,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\PermissionsTable',1,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(9,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\PersistencesTable',1,'2019-01-28 21:08:03','2019-01-28 21:08:03'),(10,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\RoleUsersTable',1,'2019-01-28 21:08:03','2019-01-28 21:08:03'),(11,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\UsersTable',1,'2019-01-28 21:08:04','2019-01-28 21:08:04'),(12,'account','\\UserFrosting\\Sprinkle\\Account\\Database\\Migrations\\v400\\VerificationsTable',1,'2019-01-28 21:08:05','2019-01-28 21:08:05');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `expires_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `password_resets_user_id_index` (`user_id`),
  KEY `password_resets_hash_index` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_roles`
--

DROP TABLE IF EXISTS `permission_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_roles` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_roles_permission_id_index` (`permission_id`),
  KEY `permission_roles_role_id_index` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_roles`
--

LOCK TABLES `permission_roles` WRITE;
/*!40000 ALTER TABLE `permission_roles` DISABLE KEYS */;
INSERT INTO `permission_roles` VALUES (1,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(2,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(2,3,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(3,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(4,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(5,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(6,1,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(7,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(8,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(9,3,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(10,1,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(11,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(12,1,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(13,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(14,3,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(15,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(16,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(17,3,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(18,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(19,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(20,3,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(21,2,'2019-01-28 21:08:02','2019-01-28 21:08:02'),(22,3,'2019-01-28 21:08:02','2019-01-28 21:08:02');
/*!40000 ALTER TABLE `permission_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'A code that references a specific action or URI that an assignee of this permission has access to.',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `conditions` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'The conditions under which members of this group have access to this hook.',
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'create_group','Create group','always()','Create a new group.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(2,'create_user','Create user','always()','Create a new user in your own group and assign default roles.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(3,'create_user_field','Set new user group','subset(fields,[\'group\'])','Set the group when creating a new user.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(4,'delete_group','Delete group','always()','Delete a group.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(5,'delete_user','Delete user','!has_role(user.id,2) && !is_master(user.id)','Delete users who are not Site Administrators.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(6,'update_account_settings','Edit user','always()','Edit your own account settings.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(7,'update_group_field','Edit group','always()','Edit basic properties of any group.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(8,'update_user_field','Edit user','!has_role(user.id,2) && subset(fields,[\'name\',\'email\',\'locale\',\'group\',\'flag_enabled\',\'flag_verified\',\'password\'])','Edit users who are not Site Administrators.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(9,'update_user_field','Edit group user','equals_num(self.group_id,user.group_id) && !is_master(user.id) && !has_role(user.id,2) && (!has_role(user.id,3) || equals_num(self.id,user.id)) && subset(fields,[\'name\',\'email\',\'locale\',\'flag_enabled\',\'flag_verified\',\'password\'])','Edit users in your own group who are not Site or Group Administrators, except yourself.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(10,'uri_account_settings','Account settings page','always()','View the account settings page.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(11,'uri_activities','Activity monitor','always()','View a list of all activities for all users.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(12,'uri_dashboard','Admin dashboard','always()','View the administrative dashboard.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(13,'uri_group','View group','always()','View the group page of any group.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(14,'uri_group','View own group','equals_num(self.group_id,group.id)','View the group page of your own group.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(15,'uri_groups','Group management page','always()','View a page containing a list of groups.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(16,'uri_user','View user','always()','View the user page of any user.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(17,'uri_user','View user','equals_num(self.group_id,user.group_id) && !is_master(user.id) && !has_role(user.id,2) && (!has_role(user.id,3) || equals_num(self.id,user.id))','View the user page of any user in your group, except the master user and Site and Group Administrators (except yourself).','2019-01-28 21:08:01','2019-01-28 21:08:01'),(18,'uri_users','User management page','always()','View a page containing a table of users.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(19,'view_group_field','View group','in(property,[\'name\',\'icon\',\'slug\',\'description\',\'users\'])','View certain properties of any group.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(20,'view_group_field','View group','equals_num(self.group_id,group.id) && in(property,[\'name\',\'icon\',\'slug\',\'description\',\'users\'])','View certain properties of your own group.','2019-01-28 21:08:02','2019-01-28 21:08:02'),(21,'view_user_field','View user','in(property,[\'user_name\',\'name\',\'email\',\'locale\',\'theme\',\'roles\',\'group\',\'activities\'])','View certain properties of any user.','2019-01-28 21:08:02','2019-01-28 21:08:02'),(22,'view_user_field','View user','equals_num(self.group_id,user.group_id) && !is_master(user.id) && !has_role(user.id,2) && (!has_role(user.id,3) || equals_num(self.id,user.id)) && in(property,[\'user_name\',\'name\',\'email\',\'locale\',\'roles\',\'group\',\'activities\'])','View certain properties of any user in your own group, except the master user and Site and Group Administrators (except yourself).','2019-01-28 21:08:02','2019-01-28 21:08:02');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persistences`
--

DROP TABLE IF EXISTS `persistences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persistences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `persistent_token` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `persistences_user_id_index` (`user_id`),
  KEY `persistences_token_index` (`token`),
  KEY `persistences_persistent_token_index` (`persistent_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persistences`
--

LOCK TABLES `persistences` WRITE;
/*!40000 ALTER TABLE `persistences` DISABLE KEYS */;
/*!40000 ALTER TABLE `persistences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_users`
--

DROP TABLE IF EXISTS `role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_users_user_id_index` (`user_id`),
  KEY `role_users_role_id_index` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_users`
--

LOCK TABLES `role_users` WRITE;
/*!40000 ALTER TABLE `role_users` DISABLE KEYS */;
INSERT INTO `role_users` VALUES (1,1,'2019-01-28 21:09:42','2019-01-28 21:09:42'),(1,2,'2019-01-28 21:09:42','2019-01-28 21:09:42'),(1,3,'2019-01-28 21:09:42','2019-01-28 21:09:42');
/*!40000 ALTER TABLE `role_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`),
  KEY `roles_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'user','User','This role provides basic user functionality.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(2,'site-admin','Site Administrator','This role is meant for \"site administrators\", who can basically do anything except create, edit, or delete other administrators.','2019-01-28 21:08:01','2019-01-28 21:08:01'),(3,'group-admin','Group Administrator','This role is meant for \"group administrators\", who can basically do anything with users in their own group, except other administrators of that group.','2019-01-28 21:08:01','2019-01-28 21:08:01');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8_unicode_ci,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `throttles`
--

DROP TABLE IF EXISTS `throttles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `throttles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `request_data` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `throttles_type_index` (`type`),
  KEY `throttles_ip_index` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `throttles`
--

LOCK TABLES `throttles` WRITE;
/*!40000 ALTER TABLE `throttles` DISABLE KEYS */;
/*!40000 ALTER TABLE `throttles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `locale` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en_US' COMMENT 'The language and locale to use for this user.',
  `theme` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'The user theme.',
  `group_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The id of the user group.',
  `flag_verified` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Set to 1 if the user has verified their account via email, 0 otherwise.',
  `flag_enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Set to 1 if the user account is currently enabled, 0 otherwise.  Disabled accounts cannot be logged in to, but they retain all of their data and settings.',
  `last_activity_id` int(10) unsigned DEFAULT NULL COMMENT 'The id of the last activity performed by this user.',
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_name_unique` (`user_name`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_user_name_index` (`user_name`),
  KEY `users_email_index` (`email`),
  KEY `users_group_id_index` (`group_id`),
  KEY `users_last_activity_id_index` (`last_activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'nowadmin','mhouser@nowmediagroup.tv','now','admin','en_US',NULL,1,1,1,362,'$2y$10$mJp6SsTIYMexAI7.UYGp2eWI7UE2GGtiAbmtaMvNMX7NFYlciYqxy',NULL,'2019-01-28 21:09:42','2019-08-20 21:51:37'),(2,'test','test@nmgclients','test','er','en_US',NULL,3,1,1,364,'$2y$10$mJp6SsTIYMexAI7.UYGp2eWI7UE2GGtiAbmtaMvNMX7NFYlciYqxy',NULL,'2019-01-28 21:09:42','2019-08-20 21:51:53');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verifications`
--

DROP TABLE IF EXISTS `verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `expires_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `verifications_user_id_index` (`user_id`),
  KEY `verifications_hash_index` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verifications`
--

LOCK TABLES `verifications` WRITE;
/*!40000 ALTER TABLE `verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `verifications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-20 15:05:47
